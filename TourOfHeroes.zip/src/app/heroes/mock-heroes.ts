import { Hero } from "./hero";

export const HEROES: Hero[] = [{
    id: 1,
    name: 'Windstorm'
  },
  {
    id: 2,
    name: 'Bombasto'
  },
  {
    id: 3,
    name: 'Magneta'
  },
  {
    id: 4,
    name: 'Tornado'
  },
  {
    id: 5,
    name: 'Mr. Nice'
  },
  {
    id: 6,
    name: 'Narco'
  },
  {
    id: 7,
    name: 'RubberMan'
  },
  {
    id: 8,
    name: 'Dynama'
  },
  {
    id: 9,
    name: 'Dr IQ'
  },
  {
    id: 10,
    name: 'Magma'
  }
];